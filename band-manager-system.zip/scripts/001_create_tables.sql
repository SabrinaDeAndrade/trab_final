-- Criar tabela de usuários (gerenciadores de banda)
create table if not exists public.band_managers (
  id uuid primary key references auth.users(id) on delete cascade,
  band_name text not null,
  created_at timestamp with time zone default now()
);

-- Criar tabela de músicos
create table if not exists public.musicians (
  id uuid primary key default gen_random_uuid(),
  band_manager_id uuid not null references public.band_managers(id) on delete cascade,
  name text not null,
  instrument text not null,
  skill_level text not null check (skill_level in ('beginner', 'intermediate', 'advanced', 'expert')),
  phone text,
  email text,
  status text not null default 'reserve' check (status in ('active', 'reserve', 'inactive')),
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Criar tabela de formações de banda
create table if not exists public.band_formations (
  id uuid primary key default gen_random_uuid(),
  band_manager_id uuid not null references public.band_managers(id) on delete cascade,
  name text not null,
  description text,
  created_at timestamp with time zone default now(),
  updated_at timestamp with time zone default now()
);

-- Criar tabela de membros da formação
create table if not exists public.formation_members (
  id uuid primary key default gen_random_uuid(),
  formation_id uuid not null references public.band_formations(id) on delete cascade,
  musician_id uuid not null references public.musicians(id) on delete cascade,
  position integer not null,
  created_at timestamp with time zone default now()
);

-- Habilitar Row Level Security
alter table public.band_managers enable row level security;
alter table public.musicians enable row level security;
alter table public.band_formations enable row level security;
alter table public.formation_members enable row level security;

-- Políticas de segurança para band_managers
create policy "band_managers_select_own"
  on public.band_managers for select
  using (auth.uid() = id);

create policy "band_managers_update_own"
  on public.band_managers for update
  using (auth.uid() = id);

-- Políticas de segurança para musicians
create policy "musicians_select_own"
  on public.musicians for select
  using (band_manager_id = (select id from public.band_managers where id = auth.uid()));

create policy "musicians_insert_own"
  on public.musicians for insert
  with check (band_manager_id = (select id from public.band_managers where id = auth.uid()));

create policy "musicians_update_own"
  on public.musicians for update
  using (band_manager_id = (select id from public.band_managers where id = auth.uid()));

create policy "musicians_delete_own"
  on public.musicians for delete
  using (band_manager_id = (select id from public.band_managers where id = auth.uid()));

-- Políticas de segurança para band_formations
create policy "band_formations_select_own"
  on public.band_formations for select
  using (band_manager_id = (select id from public.band_managers where id = auth.uid()));

create policy "band_formations_insert_own"
  on public.band_formations for insert
  with check (band_manager_id = (select id from public.band_managers where id = auth.uid()));

create policy "band_formations_update_own"
  on public.band_formations for update
  using (band_manager_id = (select id from public.band_managers where id = auth.uid()));

create policy "band_formations_delete_own"
  on public.band_formations for delete
  using (band_manager_id = (select id from public.band_managers where id = auth.uid()));

-- Políticas de segurança para formation_members
create policy "formation_members_select_own"
  on public.formation_members for select
  using (
    formation_id in (
      select id from public.band_formations 
      where band_manager_id = (select id from public.band_managers where id = auth.uid())
    )
  );

create policy "formation_members_insert_own"
  on public.formation_members for insert
  with check (
    formation_id in (
      select id from public.band_formations 
      where band_manager_id = (select id from public.band_managers where id = auth.uid())
    )
  );

create policy "formation_members_update_own"
  on public.formation_members for update
  using (
    formation_id in (
      select id from public.band_formations 
      where band_manager_id = (select id from public.band_managers where id = auth.uid())
    )
  );

create policy "formation_members_delete_own"
  on public.formation_members for delete
  using (
    formation_id in (
      select id from public.band_formations 
      where band_manager_id = (select id from public.band_managers where id = auth.uid())
    )
  );
