-- Trigger para criar band_manager automaticamente ao signup
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.band_managers (id, band_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data ->> 'band_name', 'My Band')
  )
  on conflict (id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;

create trigger on_auth_user_created
  after insert on auth.users
  for each row
  execute function public.handle_new_user();
