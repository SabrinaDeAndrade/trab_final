"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Navbar } from "@/components/navbar"
import { AddFormationModal } from "@/components/add-formation-modal"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"

interface Formation {
  id: string
  name: string
  description: string | null
  created_at: string
}

interface Musician {
  id: string
  name: string
  instrument: string
  skill_level: string
}

interface FormationMember {
  id: string
  musician_id: string
  position: number
  musician: Musician
}

export default function FormationsPage() {
  const [formations, setFormations] = useState<Formation[]>([])
  const [musicians, setMusicians] = useState<Musician[]>([])
  const [formationMembers, setFormationMembers] = useState<Record<string, FormationMember[]>>({})
  const [isLoading, setIsLoading] = useState(true)
  const [selectedFormationId, setSelectedFormationId] = useState<string | null>(null)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchData = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      // Fetch formations
      const { data: formationsData } = await supabase
        .from("band_formations")
        .select("*")
        .eq("band_manager_id", user.id)
        .order("created_at", { ascending: false })

      if (formationsData) {
        setFormations(formationsData as Formation[])
      }

      // Fetch musicians
      const { data: musiciansData } = await supabase
        .from("musicians")
        .select("*")
        .eq("band_manager_id", user.id)
        .eq("status", "active")

      if (musiciansData) {
        setMusicians(musiciansData as Musician[])
      }

      // Fetch formation members for each formation
      if (formationsData) {
        const membersMap: Record<string, FormationMember[]> = {}
        for (const formation of formationsData) {
          const { data: members } = await supabase
            .from("formation_members")
            .select(
              `
              id,
              musician_id,
              position,
              musician:musicians(id, name, instrument, skill_level)
            `,
            )
            .eq("formation_id", formation.id)
            .order("position", { ascending: true })

          if (members) {
            membersMap[formation.id] = members as FormationMember[]
          }
        }
        setFormationMembers(membersMap)
      }

      setIsLoading(false)
    }

    fetchData()
  }, [supabase, router])

  const handleAddMemberToFormation = async (formationId: string, musicianId: string) => {
    const position = (formationMembers[formationId]?.length || 0) + 1

    if (position > 5) {
      alert("Formation cannot have more than 5 members")
      return
    }

    const { error } = await supabase.from("formation_members").insert({
      formation_id: formationId,
      musician_id: musicianId,
      position,
    })

    if (!error) {
      const { data: members } = await supabase
        .from("formation_members")
        .select(
          `
          id,
          musician_id,
          position,
          musician:musicians(id, name, instrument, skill_level)
        `,
        )
        .eq("formation_id", formationId)
        .order("position", { ascending: true })

      if (members) {
        setFormationMembers({
          ...formationMembers,
          [formationId]: members as FormationMember[],
        })
      }
    }
  }

  const handleRemoveMemberFromFormation = async (memberId: string, formationId: string) => {
    await supabase.from("formation_members").delete().eq("id", memberId)

    setFormationMembers({
      ...formationMembers,
      [formationId]: formationMembers[formationId].filter((m) => m.id !== memberId),
    })
  }

  const handleDeleteFormation = async (id: string) => {
    await supabase.from("band_formations").delete().eq("id", id)
    setFormations(formations.filter((f) => f.id !== id))
  }

  if (isLoading) {
    return (
      <div>
        <Navbar />
        <div className="flex items-center justify-center h-96">Loading...</div>
      </div>
    )
  }

  return (
    <div>
      <Navbar />
      <main className="p-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold">Band Formations</h1>
            <AddFormationModal onSuccess={() => window.location.reload()} />
          </div>

          {formations.length === 0 ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <p className="text-muted-foreground mb-4">No formations created yet</p>
                <AddFormationModal onSuccess={() => window.location.reload()} />
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-6">
              {formations.map((formation) => {
                const members = formationMembers[formation.id] || []
                const isFull = members.length >= 5

                return (
                  <Card key={formation.id}>
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle>{formation.name}</CardTitle>
                          {formation.description && <CardDescription>{formation.description}</CardDescription>}
                        </div>
                        <Button variant="destructive" size="sm" onClick={() => handleDeleteFormation(formation.id)}>
                          Delete
                        </Button>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-semibold mb-3">Members ({members.length}/5)</h4>
                          {members.length === 0 ? (
                            <p className="text-sm text-muted-foreground mb-4">No members added yet</p>
                          ) : (
                            <div className="space-y-2 mb-4">
                              {members.map((member) => (
                                <div key={member.id} className="flex justify-between items-center p-3 bg-muted rounded">
                                  <div className="flex-1">
                                    <p className="font-medium">{member.musician.name}</p>
                                    <div className="flex gap-2 mt-1">
                                      <Badge variant="outline" className="text-xs">
                                        {member.musician.instrument}
                                      </Badge>
                                      <Badge variant="secondary" className="text-xs">
                                        {member.musician.skill_level}
                                      </Badge>
                                    </div>
                                  </div>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleRemoveMemberFromFormation(member.id, formation.id)}
                                  >
                                    Remove
                                  </Button>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>

                        {!isFull && musicians.length > 0 && (
                          <Dialog>
                            <DialogTrigger asChild>
                              <Button variant="outline" className="w-full bg-transparent">
                                Add Member
                              </Button>
                            </DialogTrigger>
                            <DialogContent>
                              <DialogHeader>
                                <DialogTitle>Add Member to {formation.name}</DialogTitle>
                              </DialogHeader>
                              <div className="space-y-2 max-h-96 overflow-y-auto">
                                {musicians
                                  .filter((m) => !members.some((mem) => mem.musician_id === m.id))
                                  .map((musician) => (
                                    <Button
                                      key={musician.id}
                                      variant="outline"
                                      className="w-full justify-start bg-transparent"
                                      onClick={() => {
                                        handleAddMemberToFormation(formation.id, musician.id)
                                      }}
                                    >
                                      <div className="text-left">
                                        <p className="font-medium">{musician.name}</p>
                                        <p className="text-xs text-muted-foreground">{musician.instrument}</p>
                                      </div>
                                    </Button>
                                  ))}
                              </div>
                            </DialogContent>
                          </Dialog>
                        )}

                        {isFull && (
                          <div className="p-3 bg-yellow-100 text-yellow-800 rounded text-sm">
                            This formation is full (5 members max)
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
