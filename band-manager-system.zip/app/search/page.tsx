"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Navbar } from "@/components/navbar"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Musician {
  id: string
  name: string
  instrument: string
  skill_level: string
  phone: string | null
  email: string | null
  status: string
}

export default function SearchPage() {
  const [musicians, setMusicians] = useState<Musician[]>([])
  const [filteredMusicians, setFilteredMusicians] = useState<Musician[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [searchQuery, setSearchQuery] = useState("")
  const [filterInstrument, setFilterInstrument] = useState("all")
  const [filterSkillLevel, setFilterSkillLevel] = useState("all")
  const [filterStatus, setFilterStatus] = useState("all")
  const [instruments, setInstruments] = useState<string[]>([])
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchMusicians = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      const { data, error } = await supabase
        .from("musicians")
        .select("*")
        .eq("band_manager_id", user.id)
        .order("created_at", { ascending: false })

      if (!error && data) {
        setMusicians(data as Musician[])
        const uniqueInstruments = Array.from(new Set((data as Musician[]).map((m) => m.instrument)))
        setInstruments(uniqueInstruments as string[])
      }
      setIsLoading(false)
    }

    fetchMusicians()
  }, [supabase, router])

  useEffect(() => {
    let results = musicians

    // Filter by search query (name or instrument)
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      results = results.filter(
        (m) => m.name.toLowerCase().includes(query) || m.instrument.toLowerCase().includes(query),
      )
    }

    // Filter by instrument
    if (filterInstrument !== "all") {
      results = results.filter((m) => m.instrument === filterInstrument)
    }

    // Filter by skill level
    if (filterSkillLevel !== "all") {
      results = results.filter((m) => m.skill_level === filterSkillLevel)
    }

    // Filter by status
    if (filterStatus !== "all") {
      results = results.filter((m) => m.status === filterStatus)
    }

    setFilteredMusicians(results)
  }, [searchQuery, filterInstrument, filterSkillLevel, filterStatus, musicians])

  const getSkillColor = (level: string) => {
    const colors: Record<string, string> = {
      beginner: "bg-blue-100 text-blue-800",
      intermediate: "bg-green-100 text-green-800",
      advanced: "bg-purple-100 text-purple-800",
      expert: "bg-red-100 text-red-800",
    }
    return colors[level] || "bg-gray-100 text-gray-800"
  }

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      active: "bg-green-100 text-green-800",
      reserve: "bg-yellow-100 text-yellow-800",
      inactive: "bg-gray-100 text-gray-800",
    }
    return colors[status] || "bg-gray-100 text-gray-800"
  }

  if (isLoading) {
    return (
      <div>
        <Navbar />
        <div className="flex items-center justify-center h-96">Loading...</div>
      </div>
    )
  }

  return (
    <div>
      <Navbar />
      <main className="p-6">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl font-bold mb-6">Search Musicians</h1>

          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Search by name or instrument</label>
                  <Input
                    placeholder="Search..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="mt-1"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="text-sm font-medium">Instrument</label>
                    <Select value={filterInstrument} onValueChange={setFilterInstrument}>
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="All instruments" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All instruments</SelectItem>
                        {instruments.map((instrument) => (
                          <SelectItem key={instrument} value={instrument}>
                            {instrument}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium">Skill Level</label>
                    <Select value={filterSkillLevel} onValueChange={setFilterSkillLevel}>
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="All levels" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All levels</SelectItem>
                        <SelectItem value="beginner">Beginner</SelectItem>
                        <SelectItem value="intermediate">Intermediate</SelectItem>
                        <SelectItem value="advanced">Advanced</SelectItem>
                        <SelectItem value="expert">Expert</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium">Status</label>
                    <Select value={filterStatus} onValueChange={setFilterStatus}>
                      <SelectTrigger className="mt-1">
                        <SelectValue placeholder="All statuses" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All statuses</SelectItem>
                        <SelectItem value="active">Active</SelectItem>
                        <SelectItem value="reserve">Reserve</SelectItem>
                        <SelectItem value="inactive">Inactive</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="text-sm text-muted-foreground">
                  Found {filteredMusicians.length} musician{filteredMusicians.length !== 1 ? "s" : ""}
                </div>
              </div>
            </CardContent>
          </Card>

          {filteredMusicians.length === 0 ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <p className="text-muted-foreground">No musicians found matching your search criteria</p>
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {filteredMusicians.map((musician) => (
                <Card key={musician.id}>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold mb-2">{musician.name}</h3>
                        <div className="flex flex-wrap gap-2 mb-3">
                          <Badge className={getSkillColor(musician.skill_level)}>{musician.skill_level}</Badge>
                          <Badge className={getStatusColor(musician.status)}>{musician.status}</Badge>
                          <Badge variant="outline">{musician.instrument}</Badge>
                        </div>
                        <div className="text-sm text-muted-foreground space-y-1">
                          {musician.email && <p>Email: {musician.email}</p>}
                          {musician.phone && <p>Phone: {musician.phone}</p>}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
