import { createClient } from "@/lib/supabase/server"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { Navbar } from "@/components/navbar"

export default async function Home() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  return (
    <>
      <Navbar user={user} />
      <main className="min-h-svh bg-gradient-to-br from-primary via-primary/95 to-primary/90">
        <div className="flex flex-col items-center justify-center min-h-svh px-4 py-20">
          <div className="max-w-2xl w-full space-y-8 text-center">
            {/* Hero Section */}
            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl font-bold text-primary-foreground">Band Manager</h1>
              <p className="text-xl text-primary-foreground/90">
                Organize your musicians, create formations, and manage your band with ease
              </p>
            </div>

            {/* Features */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 py-12">
              <div className="bg-white/10 backdrop-blur p-6 rounded-lg border border-white/20">
                <h3 className="text-lg font-semibold text-primary-foreground mb-2">Manage Musicians</h3>
                <p className="text-primary-foreground/80 text-sm">
                  Keep track of all your band members with detailed information
                </p>
              </div>
              <div className="bg-white/10 backdrop-blur p-6 rounded-lg border border-white/20">
                <h3 className="text-lg font-semibold text-primary-foreground mb-2">Create Formations</h3>
                <p className="text-primary-foreground/80 text-sm">
                  Build different band lineups with up to 5 active members
                </p>
              </div>
              <div className="bg-white/10 backdrop-blur p-6 rounded-lg border border-white/20">
                <h3 className="text-lg font-semibold text-primary-foreground mb-2">Search & Filter</h3>
                <p className="text-primary-foreground/80 text-sm">
                  Quickly find musicians by name, instrument, or skill level
                </p>
              </div>
            </div>

            {/* CTA Buttons */}
            <div className="space-y-4 pt-8">
              {user ? (
                <div className="space-y-3">
                  <p className="text-primary-foreground/90">Welcome back! Ready to manage your band?</p>
                  <Link href="/dashboard" className="block">
                    <Button className="w-full" size="lg">
                      Go to Dashboard
                    </Button>
                  </Link>
                </div>
              ) : (
                <div className="space-y-3">
                  <p className="text-primary-foreground/90">Get started with Band Manager today</p>
                  <div className="flex flex-col sm:flex-row gap-3 justify-center">
                    <Link href="/auth/login" className="flex-1">
                      <Button className="w-full" size="lg" variant="secondary">
                        Login
                      </Button>
                    </Link>
                    <Link href="/auth/sign-up" className="flex-1">
                      <Button className="w-full" size="lg">
                        Create Account
                      </Button>
                    </Link>
                  </div>
                </div>
              )}
            </div>

            {/* Footer Text */}
            <div className="pt-12 text-sm text-primary-foreground/70 max-w-md mx-auto">
              <p>
                Band Manager helps musicians and band leaders organize their lineup and keep track of who's performing
                in each formation.
              </p>
            </div>
          </div>
        </div>
      </main>
    </>
  )
}
