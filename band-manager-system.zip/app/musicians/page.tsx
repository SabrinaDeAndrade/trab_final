"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Navbar } from "@/components/navbar"
import { AddMusicianModal } from "@/components/add-musician-modal"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface Musician {
  id: string
  name: string
  instrument: string
  skill_level: string
  phone: string | null
  email: string | null
  status: string
}

export default function MusiciansPage() {
  const [musicians, setMusicians] = useState<Musician[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchMusicians = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      const { data, error } = await supabase
        .from("musicians")
        .select("*")
        .eq("band_manager_id", user.id)
        .order("created_at", { ascending: false })

      if (!error && data) {
        setMusicians(data as Musician[])
      }
      setIsLoading(false)
    }

    fetchMusicians()
  }, [supabase, router])

  const handleDeleteMusician = async (id: string) => {
    await supabase.from("musicians").delete().eq("id", id)
    setMusicians(musicians.filter((m) => m.id !== id))
  }

  const handleStatusChange = async (id: string, newStatus: string) => {
    await supabase.from("musicians").update({ status: newStatus }).eq("id", id)

    setMusicians(musicians.map((m) => (m.id === id ? { ...m, status: newStatus } : m)))
  }

  const getSkillColor = (level: string) => {
    const colors: Record<string, string> = {
      beginner: "bg-blue-100 text-blue-800",
      intermediate: "bg-green-100 text-green-800",
      advanced: "bg-purple-100 text-purple-800",
      expert: "bg-red-100 text-red-800",
    }
    return colors[level] || "bg-gray-100 text-gray-800"
  }

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      active: "bg-green-100 text-green-800",
      reserve: "bg-yellow-100 text-yellow-800",
      inactive: "bg-gray-100 text-gray-800",
    }
    return colors[status] || "bg-gray-100 text-gray-800"
  }

  if (isLoading) {
    return (
      <div>
        <Navbar />
        <div className="flex items-center justify-center h-96">Loading...</div>
      </div>
    )
  }

  return (
    <div>
      <Navbar />
      <main className="p-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold">Musicians</h1>
            <AddMusicianModal onSuccess={() => window.location.reload()} />
          </div>

          {musicians.length === 0 ? (
            <Card>
              <CardContent className="pt-6 text-center">
                <p className="text-muted-foreground mb-4">No musicians added yet</p>
                <AddMusicianModal onSuccess={() => window.location.reload()} />
              </CardContent>
            </Card>
          ) : (
            <div className="grid gap-4">
              {musicians.map((musician) => (
                <Card key={musician.id}>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold mb-2">{musician.name}</h3>
                        <div className="flex flex-wrap gap-2 mb-3">
                          <Badge className={getSkillColor(musician.skill_level)}>{musician.skill_level}</Badge>
                          <Badge className={getStatusColor(musician.status)}>{musician.status}</Badge>
                          <Badge variant="outline">{musician.instrument}</Badge>
                        </div>
                        <div className="text-sm text-muted-foreground space-y-1">
                          {musician.email && <p>Email: {musician.email}</p>}
                          {musician.phone && <p>Phone: {musician.phone}</p>}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <select
                          value={musician.status}
                          onChange={(e) => handleStatusChange(musician.id, e.target.value)}
                          className="px-3 py-1 border rounded text-sm"
                        >
                          <option value="active">Active</option>
                          <option value="reserve">Reserve</option>
                          <option value="inactive">Inactive</option>
                        </select>
                        <Button variant="destructive" size="sm" onClick={() => handleDeleteMusician(musician.id)}>
                          Delete
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </main>
    </div>
  )
}
