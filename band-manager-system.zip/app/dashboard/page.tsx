"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Navbar } from "@/components/navbar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"

interface BandManager {
  band_name: string
}

export default function DashboardPage() {
  const [bandData, setBandData] = useState<BandManager | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()
  const supabase = createClient()

  useEffect(() => {
    const fetchBandData = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        router.push("/auth/login")
        return
      }

      const { data, error } = await supabase.from("band_managers").select("band_name").eq("id", user.id).single()

      if (!error) {
        setBandData(data as BandManager)
      }
      setIsLoading(false)
    }

    fetchBandData()
  }, [supabase, router])

  if (isLoading) {
    return (
      <div>
        <Navbar />
        <div className="flex items-center justify-center h-96">Loading...</div>
      </div>
    )
  }

  return (
    <div>
      <Navbar />
      <main className="p-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid gap-6">
            <div>
              <h1 className="text-3xl font-bold mb-2">{bandData?.band_name || "My Band"}</h1>
              <p className="text-muted-foreground">Manage your band members and formations</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm font-medium">Total Musicians</CardTitle>
                  <CardDescription>Musicians in your band</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">0</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-sm font-medium">Active Members</CardTitle>
                  <CardDescription>Currently in formations</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">0</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-sm font-medium">Formations</CardTitle>
                  <CardDescription>Band lineups created</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="text-3xl font-bold">0</div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}
