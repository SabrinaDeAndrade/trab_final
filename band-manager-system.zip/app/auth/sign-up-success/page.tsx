import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"

export default function SignUpSuccessPage() {
  return (
    <div className="flex min-h-svh w-full items-center justify-center p-4 bg-gradient-to-br from-primary to-primary/80">
      <div className="w-full max-w-sm">
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">Sign Up Successful</CardTitle>
            <CardDescription>Verify your email to continue</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm">
              We've sent a confirmation link to your email. Please check your inbox and click the link to verify your
              account.
            </p>
            <Link href="/auth/login" className="block">
              <Button className="w-full">Go to Login</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
