"use client"

import type { Musician } from "@/components/dashboard-content"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Music, Trash2, UserCheck, UserX, Info } from "lucide-react"
import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"

type MusicianCardProps = {
  musician: Musician
  onToggleStatus: (id: string) => void
  onDelete: (id: string) => void
}

export function MusicianCard({ musician, onToggleStatus, onDelete }: MusicianCardProps) {
  const [showDetails, setShowDetails] = useState(false)

  return (
    <>
      <Card className="border-slate-700 bg-slate-800/50 backdrop-blur hover:bg-slate-800/70 transition-colors">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              {musician.image ? (
                <img
                  src={musician.image || "/placeholder.svg"}
                  alt={musician.name}
                  className="w-12 h-12 rounded-full object-cover"
                  onError={(e) => {
                    e.currentTarget.style.display = "none"
                    e.currentTarget.nextElementSibling?.classList.remove("hidden")
                  }}
                />
              ) : null}
              <div
                className={`w-12 h-12 rounded-full bg-purple-600 flex items-center justify-center ${musician.image ? "hidden" : ""}`}
              >
                <Music className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-white text-lg">{musician.name}</CardTitle>
                <p className="text-sm text-purple-300 font-medium">{musician.instrument}</p>
                <p className="text-xs text-slate-400">{musician.genre}</p>
              </div>
            </div>
            <Button
              onClick={() => setShowDetails(true)}
              size="sm"
              variant="ghost"
              className="text-slate-400 hover:text-white"
            >
              <Info className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-1.5">
            {musician.skills.map((skill, index) => (
              <Badge key={index} variant="secondary" className="bg-slate-700 text-slate-200 border-slate-600">
                {skill}
              </Badge>
            ))}
          </div>

          <div className="flex items-center gap-2 pt-2">
            <Button
              onClick={() => onToggleStatus(musician.id)}
              size="sm"
              variant={musician.isActive ? "outline" : "default"}
              className={
                musician.isActive
                  ? "flex-1 border-slate-600 text-slate-300 hover:bg-slate-700"
                  : "flex-1 bg-purple-600 hover:bg-purple-700"
              }
            >
              {musician.isActive ? (
                <>
                  <UserX className="w-4 h-4 mr-1" />
                  Para Reserva
                </>
              ) : (
                <>
                  <UserCheck className="w-4 h-4 mr-1" />
                  Ativar
                </>
              )}
            </Button>
            <Button
              onClick={() => onDelete(musician.id)}
              size="sm"
              variant="outline"
              className="border-red-600 text-red-400 hover:bg-red-950/50"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      <Dialog open={showDetails} onOpenChange={setShowDetails}>
        <DialogContent className="bg-slate-800 border-slate-700 text-white">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              {musician.image ? (
                <img
                  src={musician.image || "/placeholder.svg"}
                  alt={musician.name}
                  className="w-12 h-12 rounded-full object-cover"
                />
              ) : (
                <div className="w-12 h-12 rounded-full bg-purple-600 flex items-center justify-center">
                  <Music className="w-6 h-6 text-white" />
                </div>
              )}
              <div>
                <div>{musician.name}</div>
                <div className="text-sm text-purple-300 font-normal">{musician.instrument}</div>
              </div>
            </DialogTitle>
            <DialogDescription className="text-slate-400">Informações detalhadas do músico</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <h4 className="text-sm font-semibold text-slate-300 mb-1">Estilo Musical</h4>
              <p className="text-slate-100">{musician.genre}</p>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-slate-300 mb-2">Habilidades</h4>
              <div className="flex flex-wrap gap-2">
                {musician.skills.map((skill, index) => (
                  <Badge key={index} variant="secondary" className="bg-slate-700 text-slate-200 border-slate-600">
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-slate-300 mb-1">Biografia</h4>
              <p className="text-slate-100 leading-relaxed">{musician.bio}</p>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-slate-300 mb-1">Status</h4>
              <Badge variant={musician.isActive ? "default" : "secondary"} className="bg-purple-600">
                {musician.isActive ? "Membro Ativo" : "Reserva"}
              </Badge>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  )
}
