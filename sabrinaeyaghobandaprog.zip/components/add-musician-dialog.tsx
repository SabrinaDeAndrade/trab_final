"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import type { Musician } from "@/components/dashboard-content"
import { Badge } from "@/components/ui/badge"
import { X } from "lucide-react"

type AddMusicianDialogProps = {
  open: boolean
  onOpenChange: (open: boolean) => void
  onAdd: (musician: Omit<Musician, "id">) => void
  activeCount: number
}

export function AddMusicianDialog({ open, onOpenChange, onAdd, activeCount }: AddMusicianDialogProps) {
  const [name, setName] = useState("")
  const [instrument, setInstrument] = useState("")
  const [genre, setGenre] = useState("")
  const [image, setImage] = useState("")
  const [bio, setBio] = useState("")
  const [skillInput, setSkillInput] = useState("")
  const [skills, setSkills] = useState<string[]>([])
  const [isActive, setIsActive] = useState(true)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (isActive && activeCount >= 5) {
      alert("Limite máximo de 5 membros ativos atingido. Adicione como reserva ou mova um membro ativo para reserva.")
      return
    }

    onAdd({
      name,
      instrument,
      skills,
      genre,
      image: image || undefined,
      bio,
      isActive,
    })

    setName("")
    setInstrument("")
    setGenre("")
    setImage("")
    setBio("")
    setSkillInput("")
    setSkills([])
    setIsActive(true)
    onOpenChange(false)
  }

  const handleAddSkill = () => {
    if (skillInput.trim() && !skills.includes(skillInput.trim())) {
      setSkills([...skills, skillInput.trim()])
      setSkillInput("")
    }
  }

  const handleRemoveSkill = (skillToRemove: string) => {
    setSkills(skills.filter((s) => s !== skillToRemove))
  }

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault()
      handleAddSkill()
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-slate-800 border-slate-700 text-white max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Adicionar Novo Músico</DialogTitle>
          <DialogDescription className="text-slate-400">
            Preencha as informações do músico para adicioná-lo à banda.
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name">Nome</Label>
            <Input
              id="name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Nome completo"
              required
              className="bg-slate-700 border-slate-600 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="instrument">Instrumento</Label>
            <Input
              id="instrument"
              value={instrument}
              onChange={(e) => setInstrument(e.target.value)}
              placeholder="Ex: Guitarra, Bateria, Vocal..."
              required
              className="bg-slate-700 border-slate-600 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="genre">Estilo Musical</Label>
            <Input
              id="genre"
              value={genre}
              onChange={(e) => setGenre(e.target.value)}
              placeholder="Ex: Rock, Metal, Jazz..."
              required
              className="bg-slate-700 border-slate-600 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="image">Imagem (URL)</Label>
            <Input
              id="image"
              value={image}
              onChange={(e) => setImage(e.target.value)}
              placeholder="https://exemplo.com/foto.jpg"
              className="bg-slate-700 border-slate-600 text-white"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="bio">Biografia</Label>
            <Textarea
              id="bio"
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Conte um pouco sobre o músico..."
              rows={3}
              required
              className="bg-slate-700 border-slate-600 text-white resize-none"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="skills">Habilidades</Label>
            <div className="flex gap-2">
              <Input
                id="skills"
                value={skillInput}
                onChange={(e) => setSkillInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Digite uma habilidade e pressione Enter"
                className="bg-slate-700 border-slate-600 text-white"
              />
              <Button
                type="button"
                onClick={handleAddSkill}
                variant="outline"
                className="border-slate-600 bg-transparent"
              >
                Adicionar
              </Button>
            </div>
            {skills.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {skills.map((skill, index) => (
                  <Badge key={index} variant="secondary" className="bg-slate-700 text-slate-200 border-slate-600">
                    {skill}
                    <button type="button" onClick={() => handleRemoveSkill(skill)} className="ml-1 hover:text-red-400">
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}
          </div>

          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="isActive"
              checked={isActive}
              onChange={(e) => setIsActive(e.target.checked)}
              className="w-4 h-4"
              disabled={activeCount >= 5}
            />
            <Label htmlFor="isActive" className="cursor-pointer">
              Adicionar como membro ativo {activeCount >= 5 && isActive && "(Limite atingido: 5/5)"}
            </Label>
          </div>
          {activeCount >= 5 && (
            <p className="text-sm text-amber-400">
              ⚠️ Limite de membros ativos atingido (5/5). Novos músicos serão adicionados como reserva.
            </p>
          )}

          <div className="flex gap-2 pt-4">
            <Button type="submit" className="flex-1 bg-purple-600 hover:bg-purple-700">
              Adicionar Músico
            </Button>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} className="border-slate-600">
              Cancelar
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  )
}
