"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { MusicianCard } from "@/components/musician-card"
import { AddMusicianDialog } from "@/components/add-musician-dialog"
import { Plus, LogOut, Search, User, Music } from "lucide-react"

export type Musician = {
  id: string
  name: string
  instrument: string
  skills: string[]
  genre: string
  photo?: string
  image?: string
  bio: string
  isActive: boolean
}

// Mock data
const initialMusicians: Musician[] = [
  {
    id: "1",
    name: "João Silva",
    instrument: "Guitarra",
    skills: ["Solo", "Ritmo", "Composição"],
    genre: "Rock",
    bio: "Guitarrista experiente com 15 anos de carreira.",
    isActive: true,
  },
  {
    id: "2",
    name: "Maria Santos",
    instrument: "Bateria",
    skills: ["Rock", "Metal", "Punk"],
    genre: "Metal",
    bio: "Baterista poderosa e precisa.",
    isActive: true,
  },
  {
    id: "3",
    name: "Pedro Costa",
    instrument: "Baixo",
    skills: ["Slap", "Groove", "Walking Bass"],
    genre: "Funk",
    bio: "Baixista versátil com groove marcante.",
    isActive: true,
  },
  {
    id: "4",
    name: "Ana Lima",
    instrument: "Vocal",
    skills: ["Rock", "Blues", "Soul"],
    genre: "Blues",
    bio: "Vocalista com voz potente e expressiva.",
    isActive: true,
  },
  {
    id: "5",
    name: "Carlos Mendes",
    instrument: "Teclado",
    skills: ["Piano", "Sintetizador", "Órgão"],
    genre: "Rock Progressivo",
    bio: "Tecladista criativo e inovador.",
    isActive: false,
  },
  {
    id: "6",
    name: "Fernanda Rocha",
    instrument: "Guitarra",
    skills: ["Ritmo", "Backing Vocal"],
    genre: "Pop Rock",
    bio: "Guitarrista rítmica com ótima presença de palco.",
    isActive: false,
  },
]

export function DashboardContent() {
  const router = useRouter()
  const [musicians, setMusicians] = useState<Musician[]>(initialMusicians)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")

  useEffect(() => {
    const isLoggedIn = localStorage.getItem("bandmanager_user")
    if (!isLoggedIn) {
      router.push("/login")
    }
  }, [router])

  const handleLogout = () => {
    localStorage.removeItem("bandmanager_user")
    router.push("/login")
  }

  const handleAddMusician = (musician: Omit<Musician, "id">) => {
    const newMusician = {
      ...musician,
      id: Date.now().toString(),
    }
    setMusicians([...musicians, newMusician])
  }

  const handleToggleStatus = (id: string) => {
    const musician = musicians.find((m) => m.id === id)
    if (!musician) return

    const activeCount = musicians.filter((m) => m.isActive).length

    if (!musician.isActive && activeCount >= 5) {
      alert("Limite máximo de 5 membros ativos atingido. Mova um membro ativo para reserva primeiro.")
      return
    }

    setMusicians(musicians.map((m) => (m.id === id ? { ...m, isActive: !m.isActive } : m)))
  }

  const handleDelete = (id: string) => {
    setMusicians(musicians.filter((m) => m.id !== id))
  }

  const filteredMusicians = musicians.filter(
    (m) =>
      m.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      m.instrument.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const activeMusicians = filteredMusicians.filter((m) => m.isActive)
  const reserveMusicians = filteredMusicians.filter((m) => !m.isActive)

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="container mx-auto p-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">BandManager</h1>
            <p className="text-slate-300">Gerencie os membros da sua banda</p>
          </div>
          <div className="flex items-center gap-3">
            <Button
              onClick={() => router.push("/profile")}
              variant="outline"
              className="border-slate-600 text-slate-300 hover:bg-slate-800 bg-transparent"
            >
              <User className="w-4 h-4 mr-2" />
              Perfil
            </Button>
            <Button
              onClick={() => router.push("/band-info")}
              variant="outline"
              className="border-slate-600 text-slate-300 hover:bg-slate-800 bg-transparent"
            >
              <Music className="w-4 h-4 mr-2" />
              Banda
            </Button>
            <Button onClick={() => setIsDialogOpen(true)} className="bg-purple-600 hover:bg-purple-700">
              <Plus className="w-4 h-4 mr-2" />
              Adicionar Músico
            </Button>
            <Button
              onClick={handleLogout}
              variant="outline"
              className="border-slate-600 text-slate-300 hover:bg-slate-800 bg-transparent"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Sair
            </Button>
          </div>
        </div>

        <div className="mb-6">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
            <Input
              type="text"
              placeholder="Buscar por nome ou instrumento..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 bg-slate-800 border-slate-700 text-white placeholder:text-slate-400"
            />
          </div>
        </div>

        {/* Active Musicians */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-4">Membros Ativos ({activeMusicians.length}/5)</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {activeMusicians.map((musician) => (
              <MusicianCard
                key={musician.id}
                musician={musician}
                onToggleStatus={handleToggleStatus}
                onDelete={handleDelete}
              />
            ))}
            {activeMusicians.length === 0 && (
              <div className="col-span-full text-center py-12 text-slate-400">
                {searchQuery
                  ? "Nenhum membro ativo encontrado."
                  : "Nenhum membro ativo. Adicione músicos para começar!"}
              </div>
            )}
          </div>
        </div>

        {/* Reserve Musicians */}
        <div>
          <h2 className="text-2xl font-bold text-white mb-4">Músicos Reserva ({reserveMusicians.length})</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {reserveMusicians.map((musician) => (
              <MusicianCard
                key={musician.id}
                musician={musician}
                onToggleStatus={handleToggleStatus}
                onDelete={handleDelete}
              />
            ))}
            {reserveMusicians.length === 0 && (
              <div className="col-span-full text-center py-12 text-slate-400">
                {searchQuery ? "Nenhum músico reserva encontrado." : "Nenhum músico na reserva."}
              </div>
            )}
          </div>
        </div>

        <AddMusicianDialog
          open={isDialogOpen}
          onOpenChange={setIsDialogOpen}
          onAdd={handleAddMusician}
          activeCount={musicians.filter((m) => m.isActive).length}
        />
      </div>
    </div>
  )
}
