import { DashboardContent } from "@/components/dashboard-content"

export const metadata = {
  title: "Dashboard - BandManager",
  description: "Gerencie os membros da sua banda",
}

export default function DashboardPage() {
  return <DashboardContent />
}
