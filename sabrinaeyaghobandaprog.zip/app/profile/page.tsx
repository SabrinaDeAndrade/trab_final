"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Save, User } from "lucide-react"

export default function ProfilePage() {
  const router = useRouter()
  const [isEditing, setIsEditing] = useState(false)
  const [userData, setUserData] = useState({
    name: "",
    email: "",
    country: "",
  })

  useEffect(() => {
    const user = localStorage.getItem("bandmanager_user")
    if (!user) {
      router.push("/login")
    } else {
      const parsedUser = JSON.parse(user)
      setUserData(parsedUser)
    }
  }, [router])

  const handleSave = () => {
    localStorage.setItem("bandmanager_user", JSON.stringify(userData))
    setIsEditing(false)
    alert("Perfil atualizado com sucesso!")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      <div className="container mx-auto max-w-2xl">
        <Button
          onClick={() => router.push("/dashboard")}
          variant="ghost"
          className="mb-6 text-slate-300 hover:text-white hover:bg-slate-800"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar ao Dashboard
        </Button>

        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-purple-600 flex items-center justify-center">
                <User className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-white text-2xl">Perfil do Gerente</CardTitle>
                <CardDescription className="text-slate-400">
                  Visualize e edite suas informações pessoais
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-slate-300">
                Nome
              </Label>
              <Input
                id="name"
                type="text"
                value={userData.name}
                onChange={(e) => setUserData({ ...userData, name: e.target.value })}
                disabled={!isEditing}
                className="bg-slate-900 border-slate-700 text-white disabled:opacity-70"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="email" className="text-slate-300">
                Email
              </Label>
              <Input
                id="email"
                type="email"
                value={userData.email}
                onChange={(e) => setUserData({ ...userData, email: e.target.value })}
                disabled={!isEditing}
                className="bg-slate-900 border-slate-700 text-white disabled:opacity-70"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="country" className="text-slate-300">
                País
              </Label>
              <Input
                id="country"
                type="text"
                value={userData.country}
                onChange={(e) => setUserData({ ...userData, country: e.target.value })}
                disabled={!isEditing}
                className="bg-slate-900 border-slate-700 text-white disabled:opacity-70"
              />
            </div>

            <div className="flex gap-3 pt-4">
              {!isEditing ? (
                <Button onClick={() => setIsEditing(true)} className="bg-purple-600 hover:bg-purple-700 w-full">
                  Editar Perfil
                </Button>
              ) : (
                <>
                  <Button onClick={handleSave} className="bg-purple-600 hover:bg-purple-700 flex-1">
                    <Save className="w-4 h-4 mr-2" />
                    Salvar
                  </Button>
                  <Button
                    onClick={() => {
                      const user = localStorage.getItem("bandmanager_user")
                      if (user) {
                        setUserData(JSON.parse(user))
                      }
                      setIsEditing(false)
                    }}
                    variant="outline"
                    className="border-slate-600 text-slate-300 hover:bg-slate-700 flex-1"
                  >
                    Cancelar
                  </Button>
                </>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
