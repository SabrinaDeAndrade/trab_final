"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { ArrowLeft, Save, Music } from "lucide-react"

export default function BandInfoPage() {
  const router = useRouter()
  const [isEditing, setIsEditing] = useState(false)
  const [bandData, setBandData] = useState({
    name: "The Rock Legends",
    genre: "Rock Progressivo",
    country: "Brasil",
    description: "Uma banda dedicada a criar experiências musicais únicas e memoráveis.",
  })

  useEffect(() => {
    const user = localStorage.getItem("bandmanager_user")
    if (!user) {
      router.push("/login")
    }

    const savedBandData = localStorage.getItem("bandmanager_band")
    if (savedBandData) {
      setBandData(JSON.parse(savedBandData))
    }
  }, [router])

  const handleSave = () => {
    localStorage.setItem("bandmanager_band", JSON.stringify(bandData))
    setIsEditing(false)
    alert("Informações da banda atualizadas com sucesso!")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      <div className="container mx-auto max-w-2xl">
        <Button
          onClick={() => router.push("/dashboard")}
          variant="ghost"
          className="mb-6 text-slate-300 hover:text-white hover:bg-slate-800"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar ao Dashboard
        </Button>

        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-purple-600 flex items-center justify-center">
                <Music className="w-6 h-6 text-white" />
              </div>
              <div>
                <CardTitle className="text-white text-2xl">Informações da Banda</CardTitle>
                <CardDescription className="text-slate-400">Visualize e edite os dados da sua banda</CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="bandName" className="text-slate-300">
                Nome da Banda
              </Label>
              <Input
                id="bandName"
                type="text"
                value={bandData.name}
                onChange={(e) => setBandData({ ...bandData, name: e.target.value })}
                disabled={!isEditing}
                className="bg-slate-900 border-slate-700 text-white disabled:opacity-70"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="genre" className="text-slate-300">
                Estilo Musical
              </Label>
              <Input
                id="genre"
                type="text"
                value={bandData.genre}
                onChange={(e) => setBandData({ ...bandData, genre: e.target.value })}
                disabled={!isEditing}
                className="bg-slate-900 border-slate-700 text-white disabled:opacity-70"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="bandCountry" className="text-slate-300">
                País
              </Label>
              <Input
                id="bandCountry"
                type="text"
                value={bandData.country}
                onChange={(e) => setBandData({ ...bandData, country: e.target.value })}
                disabled={!isEditing}
                className="bg-slate-900 border-slate-700 text-white disabled:opacity-70"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description" className="text-slate-300">
                Descrição
              </Label>
              <Textarea
                id="description"
                value={bandData.description}
                onChange={(e) => setBandData({ ...bandData, description: e.target.value })}
                disabled={!isEditing}
                rows={4}
                className="bg-slate-900 border-slate-700 text-white disabled:opacity-70 resize-none"
              />
            </div>

            <div className="flex gap-3 pt-4">
              {!isEditing ? (
                <Button onClick={() => setIsEditing(true)} className="bg-purple-600 hover:bg-purple-700 w-full">
                  Editar Informações
                </Button>
              ) : (
                <>
                  <Button onClick={handleSave} className="bg-purple-600 hover:bg-purple-700 flex-1">
                    <Save className="w-4 h-4 mr-2" />
                    Salvar
                  </Button>
                  <Button
                    onClick={() => {
                      const savedBandData = localStorage.getItem("bandmanager_band")
                      if (savedBandData) {
                        setBandData(JSON.parse(savedBandData))
                      }
                      setIsEditing(false)
                    }}
                    variant="outline"
                    className="border-slate-600 text-slate-300 hover:bg-slate-700 flex-1"
                  >
                    Cancelar
                  </Button>
                </>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
